#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <algorithm>
#include <ctime>
#include <cstdlib>

using namespace std;

// Flight struct to store flight details
struct FlightInfo {
    string flightID;
    string origin;
    string terminus;
    string departureTime;
    string arrivalTime;
    int availableSeats;
    double ticketCost;
};

// Vector to store all flights
vector<FlightInfo> flightSchedule;

// Function to generate a random flight ID
string generateFlightID() {
    static const char alphanum[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    string flightID = "FL";
    for (int i = 0; i < 4; ++i) {
        flightID += alphanum[rand() % (sizeof(alphanum) - 1)];
    }
    return flightID;
}

// Function to add a new flight
void scheduleNewFlight() {
    FlightInfo newFlight;
    newFlight.flightID = generateFlightID();
    cout << "Enter origin: ";
    cin >> newFlight.origin;
    cout << "Enter destination: ";
    cin >> newFlight.terminus;
    cout << "Enter departure time (HH:MM): ";
    cin >> newFlight.departureTime;
    cout << "Enter arrival time (HH:MM): ";
    cin >> newFlight.arrivalTime;
    cout << "Enter number of available seats: ";
    cin >> newFlight.availableSeats;
    cout << "Enter ticket price: ";
    cin >> newFlight.ticketCost;
    flightSchedule.push_back(newFlight);
    cout << "Flight " << newFlight.flightID << " scheduled successfully!" << endl;
}

// Function to display all available flights
void showFlightSchedule() {
    if (flightSchedule.empty()) {
        cout << "No flights scheduled." << endl;
    } else {
        cout << left << setw(10) << "Flight ID" << setw(15) << "Origin" << setw(15) << "Destination"
             << setw(10) << "Dep. Time" << setw(10) << "Arr. Time" << setw(10) << "Seats" << setw(10) << "Price"
             << endl;
        cout << string(80, '-') << endl;
        for (const auto& flight : flightSchedule) {
            cout << left << setw(10) << flight.flightID << setw(15) << flight.origin << setw(15) << flight.terminus
                 << setw(10) << flight.departureTime << setw(10) << flight.arrivalTime << setw(10) << flight.availableSeats
                 << setw(10) << "$" << flight.ticketCost << endl;
        }
    }
}

// Function to book a flight
void bookFlight() {
    string flightID;
    cout << "Enter flight ID to book: ";
    cin >> flightID;
    for (auto& flight : flightSchedule) {
        if (flight.flightID == flightID) {
            if (flight.availableSeats > 0) {
                flight.availableSeats--;
                cout << "Flight " << flightID << " booked successfully!" << endl;
            } else {
                cout << "No seats available for flight " << flightID << "." << endl;
            }
            return;
        }
    }
    cout << "Flight " << flightID << " not found." << endl;
}

// Function to cancel a flight
void cancelFlight() {
    string flightID;
    cout << "Enter flight ID to cancel: ";
    cin >> flightID;
    for (auto it = flightSchedule.begin(); it != flightSchedule.end(); ++it) {
        if (it->flightID == flightID) {
            flightSchedule.erase(it);
            cout << "Flight " << flightID << " canceled successfully!" << endl;
            return;
        }
    }
    cout << "Flight " << flightID << " not found." << endl;
}

// Function to search for flights
void searchFlights() {
    string origin, terminus;
    cout << "Enter origin: ";
    cin >> origin;
    cout << "Enter destination: ";
    cin >> terminus;

    bool foundFlights = false;
    cout << left << setw(10) << "Flight ID" << setw(15) << "Origin" << setw(15) << "Destination"
         << setw(10) << "Dep. Time" << setw(10) << "Arr. Time" << setw(10) << "Seats" << setw(10) << "Price"
         << endl;
    cout << string(80, '-') << endl;

    for (const auto& flight : flightSchedule) {
        if (flight.origin == origin && flight.terminus == terminus) {
            foundFlights = true;
            cout << left << setw(10) << flight.flightID << setw(15) << flight.origin << setw(15) << flight.terminus
                 << setw(10) << flight.departureTime << setw(10) << flight.arrivalTime << setw(10) << flight.availableSeats
                 << setw(10) << "$" << flight.ticketCost << endl;
        }
    }

    if (!foundFlights) {
        cout << "No flights found for the specified route." << endl;
    }
}

int main() {
    srand(static_cast<unsigned int>(time(nullptr))); // Seed random number generator

    int choice;
    do {
        cout << "\nAirline Scheduling System" << endl;
        cout << "1. Schedule New Flight" << endl;
        cout << "2. Show Flight Schedule" << endl;
        cout << "3. Book Flight" << endl;
        cout << "4. Cancel Flight" << endl;
        cout << "5. Search Flights" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                scheduleNewFlight();
                break;
            case 2:
                showFlightSchedule();
                break;
            case 3:
                bookFlight();
                break;
            case 4:
                cancelFlight();
                break;
            case 5:
                searchFlights();
                break;
            case 6:
                cout << "Exiting program..." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 6);

    return 0;
}