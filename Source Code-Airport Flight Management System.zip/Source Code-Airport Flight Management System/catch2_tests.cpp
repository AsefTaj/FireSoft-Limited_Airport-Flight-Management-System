#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include <vector>
#include <string>

// Include the source code files
#include "main.cpp"

TEST_CASE("Flight Management System", "[flight]") {
    SECTION("Generating Flight IDs") {
        std::vector<std::string> flightIDs;
        for (int i = 0; i < 10; ++i) {
            flightIDs.push_back(generateFlightID());
        }
        REQUIRE(flightIDs.size() == 10);
        REQUIRE(std::all_of(flightIDs.begin(), flightIDs.end(), [](const std::string& id) {
            return id.length() == 6 && id.substr(0, 2) == "FL";
        }));
    }

    SECTION("Scheduling New Flights") {
        flightSchedule.clear();
        scheduleNewFlight();
        REQUIRE(flightSchedule.size() == 1);
        REQUIRE(flightSchedule[0].flightID.length() == 6);
        REQUIRE(flightSchedule[0].flightID.substr(0, 2) == "FL");
    }

    SECTION("Booking Flights") {
        flightSchedule.clear();
        FlightInfo flight1 = {"FL1234", "New York", "Los Angeles", "10:00", "13:00", 100, 250.0};
        flightSchedule.push_back(flight1);

        bookFlight();  // Should fail as no flight ID is provided
        REQUIRE(flightSchedule[0].availableSeats == 100);

        bookFlight("FL1234");
        REQUIRE(flightSchedule[0].availableSeats == 99);

        bookFlight("FL9999");  // Should fail as the flight ID is not found
    }

    SECTION("Canceling Flights") {
        flightSchedule.clear();
        FlightInfo flight1 = {"FL1234", "New York", "Los Angeles", "10:00", "13:00", 100, 250.0};
        flightSchedule.push_back(flight1);

        cancelFlight();  // Should fail as no flight ID is provided
        REQUIRE(flightSchedule.size() == 1);

        cancelFlight("FL1234");
        REQUIRE(flightSchedule.empty());

        cancelFlight("FL9999");  // Should fail as the flight ID is not found
    }

    SECTION("Searching Flights") {
        flightSchedule.clear();
        FlightInfo flight1 = {"FL1234", "New York", "Los Angeles", "10:00", "13:00", 100, 250.0};
        FlightInfo flight2 = {"FL5678", "Chicago", "Miami", "14:00", "17:00", 80, 200.0};
        flightSchedule.push_back(flight1);
        flightSchedule.push_back(flight2);

        searchFlights("New York", "Los Angeles");  // Should find flight1
        searchFlights("Miami", "Chicago");  // Should not find any flights
    }
}